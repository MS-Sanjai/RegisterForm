package com.example.Registration_form;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Recover_Repository  extends JpaRepository<Recover_Model,Integer>{

}
